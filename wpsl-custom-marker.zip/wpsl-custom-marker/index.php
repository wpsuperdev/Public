<?php
echo 'Silence is gold';