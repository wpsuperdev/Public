<?php
if (!defined('ABSPATH')) die;
/*
 * Plugin Name: Custom Marker for WP Store Locator
 * Plugin URI: https://wpstorelocator.co/
 * Description: Customize the marker for each Store with custom marker uploaded.
 * Version: 1.0.0
 * Author: Vasile@Younique Creation
 * Text Domain: wpsl-custom-marker
 * Author URI: https://youniquecreation.com
 * License: GPLv2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 */

define('DOMAIN', 'wpsl-custom-marker');

if( !function_exists('is_plugin_active') ) {
    include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}

if (!is_plugin_active('wp-store-locator/wp-store-locator.php')) {
    custom_store_marker_print_error( __( 'WP Store Locator plugin must be installed and activated to use this plugin.', DOMAIN ));
} 

add_filter( 'wpsl_meta_box_fields', 'custom_store_marker_meta_box_fields' );
add_filter( 'wpsl_frontend_meta_fields', 'custom_store_marker_frontend_meta_fields' );
add_filter( 'wpsl_cpt_info_window_meta_fields', 'custom_store_marker_cpt_info_window_meta_fields', 10, 2 );

function custom_store_marker_print_error( $message ) {
    if ( ! $message ) {
        return;
    }
    // PHPCS - $message should not be escaped
    echo '<div class="error">' . $message . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}

function custom_store_marker_meta_box_fields( $meta_fields ) {
    $meta_fields[__( 'Marker', DOMAIN )] = array(
        'alternate_marker_url' => array(
            'label' => __( 'Marker Url', DOMAIN )
        )
    );
    return $meta_fields;
}

function custom_store_marker_frontend_meta_fields( $store_fields ) {
    $store_fields['wpsl_alternate_marker_url'] = array(
        'name' => 'alternateMarkerUrl'
    );
    return $store_fields;
}

function custom_store_marker_cpt_info_window_meta_fields( $meta_fields, $store_id ) {
    $meta_fields['alternateMarkerUrl'] = get_post_meta( $store_id, 'wpsl_alternate_marker_url', true );
    return $meta_fields;
}