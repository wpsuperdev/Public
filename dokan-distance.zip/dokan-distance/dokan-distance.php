<?php
/**
Plugin Name: Dokan Distance
Plugin URI: https://dokan-pro.ir/
Description: Shipping price calculation plugin according to the distance and product
Version: 1.0.1
Author: High Fly
Author URI: https://dokan-pro.ir/
WC requires at least: 3.0
WC tested up to: 4.0.1
License: GPL2
TextDomain: dokan-distance
 */

class Dokan_Distance {

    public static function init() {
        static $instance = false;

        if ( ! $instance ) {
            $instance = new Dokan_Distance();
        }

        return $instance;
    }

    public function __construct()
    {

        $this->define_constants();
        /*
         * default plugin hooks
         */
        add_action( 'plugins_loaded', [ $this, 'check_required_plugins' ] );
        add_action( 'admin_menu', array( $this, 'remove_add_on_menu' ), 16 );

        /*
         * change shipping rates according to the distance between vendors and customer
         */
        add_filter('woocommerce_package_rates',array($this, 'change_shipping_rates'), 100, 2);

        /*
         * set delivery options for product categories in admin dashboard
         */
        add_action('show_product_categories' , array($this, 'show_product_categories'));

    }


    public static function show_product_categories() {
        $dd_delivery_options_string = get_option('dd-delivery-options');
        if ($dd_delivery_options_string != '')
            $dd_delivery_options = json_decode($dd_delivery_options_string);
        else {
            $dd_delivery_options = new stdClass();
        }

        do_action('options-category-container-before');

        echo '<div class="options-category">';

        do_action('options-category-container-after');

        $taxonomy = 'product_cat';
        $orderby = 'name';
        $show_count = 0;      // 1 for yes, 0 for no
        $pad_counts = 0;      // 1 for yes, 0 for no
        $hierarchical = 1;      // 1 for yes, 0 for no
        $title = '';
        $empty = 0;

        $args = array(
            'taxonomy' => $taxonomy,
            'orderby' => $orderby,
            'show_count' => $show_count,
            'pad_counts' => $pad_counts,
            'hierarchical' => $hierarchical,
            'title_li' => $title,
            'hide_empty' => $empty
        );
        $all_categories = get_categories($args);

        do_action('options-parent-categories');

        if (count($all_categories) > 0) {
            echo '<ul>';
            foreach ($all_categories as $cat) {
                if ($cat->category_parent == 0) {
                    $category_id = $cat->term_id;
                    echo '<li>';
                    echo '<table border="0">';
                    echo '<tr><td><a href="' . get_term_link($cat->slug, 'product_cat') . '">' . $cat->name . '</a></td>';
                    ?>
                    <td>
                        <select name="dd-options[]">
                            <option value="<?=$cat->term_id?>-van" <?=selected(in_array($cat->term_id, $dd_delivery_options->van), true, true)?>>Van</option>
                            <option value="<?=$cat->term_id?>-car" <?=selected(in_array($cat->term_id, $dd_delivery_options->car), true, true)?>>Car</option>
                            <option value="<?=$cat->term_id?>-bike" <?=selected(in_array($cat->term_id, $dd_delivery_options->bike), true, true)?>>Bike</option>
                        </select>
                    </td>
                    <?php
                    echo '</tr>';
                    $args2 = array(
                        'taxonomy' => $taxonomy,
                        'child_of' => 0,
                        'parent' => $category_id,
                        'orderby' => $orderby,
                        'show_count' => $show_count,
                        'pad_counts' => $pad_counts,
                        'hierarchical' => 2,
                        'title_li' => $title,
                        'hide_empty' => $empty
                    );
                    $sub_cats = get_categories($args2);
                    do_action('options-child-categories');
                    if ($sub_cats) {
                        foreach ($sub_cats as $sub_category) {
                            echo '<tr><td>'.$sub_category->name.'</td>';
                            ?>
                            <td>
                                <select name="dd-options[]">
                                    <option value="<?=$sub_category->term_id?>-van" <?=selected(in_array($sub_category->term_id, $dd_delivery_options->van), true, true)?>>Van</option>
                                    <option value="<?=$sub_category->term_id?>-car" <?=selected(in_array($sub_category->term_id, $dd_delivery_options->car), true, true)?>>Car</option>
                                    <option value="<?=$sub_category->term_id?>-bike" <?=selected(in_array($sub_category->term_id, $dd_delivery_options->bike), true, true)?>>Bike</option>
                                </select>
                            </td>
                            <?php
                            echo '</tr>';
                        }
                    }
                    echo '</table></li>';
                }
            }
            echo '</ul>';
        }
        echo '</div>';
    }

    function change_shipping_rates($rates, $package) {

        $destination = $package['destination'];
        $customer_postcode     = $destination['postcode'];
        $contents = $package['contents'];
        $google_map_api_key = get_option('dd-map-key');//AIzaSyBUCBU8xc0toRk5-SyFyHkpiJmUMWVRsIA

        $dd_delivery_options_string = get_option('dd-delivery-options');
        if ($dd_delivery_options_string != '')
            $dd_delivery_options = json_decode($dd_delivery_options_string);
        else {
            $dd_delivery_options = new stdClass();
        }

        $delivery_titles = array(
            'van' => 'Van',
            'car' => 'Car',
            'bike' => 'Bike'
        );

        $delivery_orders = array(
            'van' => 0,
            'car' => 1,
            'bike' => 2,
        );
        $selected_delivery_option = array(
            'title' => '',
            'price' => 0,
            'order' => 2,
        );

        foreach ($contents as $key => $value) {
            $product_id = $value['product_id'];
            $product_terms = get_the_terms ( $product_id, 'product_cat' );
            foreach ( $product_terms as $product_term ) {
                $parentcats = get_ancestors($product_term->term_id, 'product_cat');
                foreach ($dd_delivery_options as $key => $options) {
                    if (in_array($product_term->term_id, $options)) {
                        if ($selected_delivery_option['order'] >= $delivery_orders[$key]){
                            $selected_delivery_option = array(
                                'title' => $delivery_titles[$key],
                                'price' => floatval(get_option('dd-'.$key.'-price')),
                                'order' => $delivery_orders[$key],
                            );
                        }
                    }
                    else {
                        foreach ($parentcats as $parentcat) {
                            if (in_array($parentcat, $options)) {
                                if ($selected_delivery_option['order'] >= $delivery_orders[$key]){
                                    $selected_delivery_option = array(
                                        'title' => $delivery_titles[$key],
                                        'price' => floatval(get_option('dd-'.$key.'-price')),
                                        'order' => $delivery_orders[$key],
                                    );
                                }
                            }
                        }
                    }
                }
            }

            $product = new WC_Product($product_id);
            $vendor_id = get_post_field( 'post_author', $product_id );
            // Get the WP_User object (the vendor) from author ID
            $vendor = new WP_User($vendor_id);

            $store_info  = dokan_get_store_info( $vendor_id ); // Get the store data
            $store_name  = $store_info['store_name'];          // Get the store name
            $store_url   = dokan_get_store_url( $vendor_id );  // Get the store URL

            $vendor_name = $vendor->display_name;              // Get the vendor name
            $vendor_address     = $vendor->billing_address_1;           // Get the vendor address
            $vendor_postcode    = $vendor->billing_postcode;          // Get the vendor postcode
            $vendor_city        = $vendor->billing_city;              // Get the vendor city
            $vendor_state       = $vendor->billing_state;             // Get the vendor state
            $vendor_country     = $vendor->billing_country;           // Get the vendor country
        }

        $query = http_build_query(
            array(
                'origins' => $vendor_postcode.",canada",
                'destinations' => $customer_postcode.",canada",
                "mode" => "driving",
                "language" => "en-EN",
                "sensor" => false,
                "key" => $google_map_api_key,
            )
        );
        $url = "https://maps.googleapis.com/maps/api/distancematrix/json?".$query;
        $data   = @file_get_contents($url);
        $result = json_decode($data, true);
        $distances = array( // converts the units
            "meters" => $result["rows"][0]["elements"][0]["distance"]["value"],
            "kilometers" => $result["rows"][0]["elements"][0]["distance"]["value"] / 1000,
            "yards" => $result["rows"][0]["elements"][0]["distance"]["value"] * 1.0936133,
            "miles" => $result["rows"][0]["elements"][0]["distance"]["value"] * 0.000621371
        );
        $kilometres = $distances['kilometers'];

        $weekDay = intval(date('w', strtotime(date_i18n('Y-m-d H:i:s'))));

        foreach ($rates as $rate_key => $rate_values) {

            $method_id = $rate_values->method_id;
            $rate_id = $rate_values->id;
            // Targeting "Flat Rate" shipping method
            if ( 'flat_rate' === $method_id ) {

                // For more than 1 vendor (count)
                // Get the original rate cost
                $orig_cost = $rates[$rate_id]->cost;

                if ($weekDay == 0 || $weekDay == 6) $new_cost = floatval(get_option('dd-rushhour-price'));
                else $new_cost = $orig_cost;
                // Set the new rate cost
                if ($kilometres > 0){
                    if ($selected_delivery_option['price'] > 0) {
                        $rates[$rate_id]->label = $selected_delivery_option['title']." Delivery";
                        $price_per_kilo = $selected_delivery_option['price'];
                    }
                    else {
                        $price_per_kilo = 1;
                    }
                    // Calculate the new rate cost
                    $new_cost += $price_per_kilo * $kilometres;

                }
                else {
                    $rates[$rate_id]->label = "No vendor address defined. Price ";
                }

                $rates[$rate_id]->cost = $new_cost;
                // Calculate the conversion rate (for below taxes)
                $conversion_rate = $new_cost / $orig_cost;
                // Taxes rate cost (if enabled)
                foreach ($rates[$rate_id]->taxes as $key => $tax){
                    if( $rates[$rate_id]->taxes[$key] > 0 ){
                        $new_tax_cost = number_format( $rates[$rate_id]->taxes[$key]*$conversion_rate, 2 );
                        $rates[$rate_id]->taxes[$key] = $new_tax_cost; // set the cost
                    }
                }
            }

        }
        return $rates;
    }

    public function remove_add_on_menu() {
        add_submenu_page( 'dokan', __( 'Dokan Distance Options', 'dokan' ), __( 'Dokan Distance', 'dokan' )
            , 'manage_options', 'dokan-distance', array( $this, 'dokan_distance_options_page' ));
    }

    function dokan_distance_options_page() {
        require_once dirname( __FILE__ ) . '/templates/admin-options.php';
    }

    function check_required_plugins() {
        if ( ! class_exists( 'WeDevs_Dokan' )) {
            if ( ! current_user_can( 'manage_options' ) ) {
                return;
            }

            add_action( 'admin_notices', array( $this, 'activation_notice' ) );
            add_action( 'wp_ajax_dokan_pro_install_dokan_lite', array( $this, 'install_dokan_lite' ) );

        }
    }

    public function init_plugin() {

    }

    function define_constants() {

    }

    /**
     * Install dokan lite
     *
     * @since 2.5.2
     *
     * @return void
     * */
    public function install_dokan_lite() {
        if ( ! isset( $_REQUEST['_wpnonce'] ) || ! wp_verify_nonce( $_REQUEST['_wpnonce'], 'dokan-pro-installer-nonce' ) ) {
            wp_send_json_error( __( 'Error: Nonce verification failed', 'dokan' ) );
        }

        include_once ABSPATH . 'wp-admin/includes/plugin-install.php';
        include_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

        $plugin = 'dokan-lite';
        $api    = plugins_api( 'plugin_information', [ 'slug' => $plugin, 'fields' => [ 'sections' => false ] ] );

        $upgrader = new Plugin_Upgrader( new WP_Ajax_Upgrader_Skin() );
        $result   = $upgrader->install( $api->download_link );
        activate_plugin( 'dokan-lite/dokan.php' );

        wp_send_json_success();
    }
}

function dokan_distance() {
    return Dokan_Distance::init();
}

dokan_distance();