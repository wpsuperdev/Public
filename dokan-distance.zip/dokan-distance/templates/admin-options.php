<?php
if (isset($_POST['dd_options_save']) && !empty($_POST['dd_options_save'])) {
    if (isset($_POST['van_price']) && floatval($_POST['van_price']) >= 0) {
        update_option('dd-van-price' , $_POST['van_price']);
    }
    if (isset($_POST['car_price']) && floatval($_POST['car_price']) >= 0) {
        update_option('dd-car-price' , $_POST['car_price']);
    }
    if (isset($_POST['bike_price']) && floatval($_POST['bike_price']) >= 0) {
        update_option('dd-bike-price' , $_POST['bike_price']);
    }

    if (isset($_POST['rushhour_price']) && floatval($_POST['rushhour_price']) >= 0) {
        update_option('dd-rushhour-price' , $_POST['rushhour_price']);
    }

    if (isset($_POST['map_key']) && !empty($_POST['map_key'])) {
        update_option('dd-map-key' , $_POST['map_key']);
    }
    if (isset($_POST['dd-options']) && !empty($_POST['dd-options'])) {
        $dd_options = $_POST['dd-options'];
        $saved_dd_options = array();
        foreach ($dd_options as $dd_option) {
            $split = explode("-", $dd_option);
            $saved_dd_options[$split[1]][] = intval($split[0]);
        }
        update_option('dd-delivery-options' , json_encode($saved_dd_options));
    }
}
?>
<div class="wrap">
    <h2 class="dd-options-title"><?php _e( 'Dokan Distance Options', 'dokan' ); ?></h2>
    <form method="post" name="dd-options-form" id="dd-options-form" enctype="multipart/form-data">
        <?php
        do_action('show_product_categories');
        ?>
        <table border="0">
            <thead>
            <tr>
                <td colspan="3" class="dd-sub-title">Delivery Options</td>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td>Van</td>
                <td>
                    <input type="text" name="van_price" value="<?=floatval(get_option('dd-van-price'))?>">
                </td>
                <td>$/Km</td>
            </tr>
            <tr>
                <td>Car</td>
                <td>
                    <input type="text" name="car_price" value="<?=floatval(get_option('dd-car-price'))?>">
                </td>
                <td>$/Km</td>
            </tr>
            <tr>
                <td>Bike</td>
                <td>
                    <input type="text" name="bike_price" value="<?=floatval(get_option('dd-bike-price'))?>">
                </td>
                <td>$/Km</td>
            </tr>
            <tr>
                <td>Rush Hour</td>
                <td>
                    <input type="text" name="rushhour_price" value="<?=floatval(get_option('dd-rushhour-price'))?>">
                </td>
                <td>$</td>
            </tr>
            </tbody>

        </table>

        <table border="0">
            <thead>
            <tr>
                <td colspan="2" class="dd-sub-title"><?php _e( 'Google Api Keys', 'dokan' ); ?></td>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td>Google Map Api Key</td>
                <td>
                    <input type="text" name="map_key" value="<?=get_option('dd-map-key')?>">
                </td>
            </tr>
            </tbody>
        </table>

        <table border="0">
            <tr>
                <td>
                    <input type="submit" name="dd_options_save" value="Save">
                </td>
            </tr>
        </table>
    </form>
</div>
<style>
    #dd-options-form table {
        margin-bottom: 30px;
    }
    #dd-options-form table input[type=text] {
        min-width: 300px;
    }
    .dd-options-title {
        font-weight: 700 !important;
        font-size: 42px !important;
    }
    .dd-sub-title {
        font-weight: 500 !important;
        font-size:24px !important;
        line-height: 36px;
    }
    .options-category > ul {
        width : 100%;
        display: inline-block;
    }
    .options-category > ul > li {
        padding: 15px;
        display: inline-block;
        margin: 5px;
        float: left;
        border: solid 1px;
    }
    .options-category > ul > li > a {
        display: block;
    }
</style>
