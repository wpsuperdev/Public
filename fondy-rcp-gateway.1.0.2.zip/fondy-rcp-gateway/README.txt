=== FONDY — Restrict Content Pro Payment Gateway integration ===
Contributors: fondyeu
Tags: payments, payment gateway, restrict content pro, online payment, merchant
Requires at least: 3.5
Tested up to: 5.4
Stable tag: 1.0.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Restrict Content Pro payment plugin allow clients make recurring payment with FONDY.

== Description ==
[This Restrict Content Pro payment plugin](https://fondy.eu/en-eu/cms/wordpress-restrict-content-pro/?utm_source=wordpress.org&utm_medium=cms) adds FONDY as payment gateway to Restrict Content Pro. FONDY can accept VISA and MasterCard securely, quickly and easily on your store in minutes. Recurring payments, simple, straightforward pricing, top notch fraud intelligence, and 24/7 support.

== Start with FONDY ==
[Create Free FONDY Account](https://portal.fondy.eu/mportal/#/account/registration?utm_source=wordpress.org&utm_medium=cms)

== Features ==
* Customize your checkout window ([Some styles](http://jsfiddle.net/8h65h91t/))
* Easy configuration - only Merchant ID and Secret Key!

== Allowed currencies ==
With us your customers can make purchases in many currencies. FONDY support  EUR, USD, GBP, RUB, UAH and some other.

== FONDY pricing ==
* Before 2500 EUR/month
Card payments:
1.8% + 0.2€
Bank transfers:
1.4% + 0.2 €
* From 2500 EUR/month
Card payments:
1.6% + 0.2€
Bank transfers:
1.2% + 0.2 €
* More 5 000 EUR/month
INDIVIDUALLY

== Frequently Asked Questions ==
Some answers you can find here [FAQ](https://fondy.eu/faq/?utm_source=wordpress.org&utm_medium=cms)

== Installation ==
1. Make sure you have the latest version of the Restrict Content Pro plug-in
2. Unzip this plugin in the directory `/wp-content/plugins/`
3. Activate the plug-in in the menu "Plugins"
Configuration:
1. Go to "Restrict > Settings > Payments" and find FONDY and activate
2. In the "FONDY RCP payment" tab, enter the FONDY Secret Key and FONDY MID.
3. Save settings.

== Screenshots ==
1. FONDY options
2. Checkout page

== Changelog ==
= 1.0.0 = 
* First release